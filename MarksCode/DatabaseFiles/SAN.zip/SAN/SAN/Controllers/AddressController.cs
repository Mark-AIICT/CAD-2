using Microsoft.AspNetCore.Mvc;
using SAN.Models;

namespace SAN.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AddressController : ControllerBase
    {
        

        private readonly ILogger<AddressController> _logger;

        public AddressController(ILogger<AddressController> logger)
        {
            _logger = logger;
        }

        [HttpGet()]
        public IEnumerable<Address> Get(int addressid)
        {
            CADWORKSADVENTUREWORKS_DATAMDFContext ctx = new CADWORKSADVENTUREWORKS_DATAMDFContext();
            var adresses = ctx.Addresses.Where(c => c.AddressId== addressid);
            return adresses.ToArray();
        }
    }
}