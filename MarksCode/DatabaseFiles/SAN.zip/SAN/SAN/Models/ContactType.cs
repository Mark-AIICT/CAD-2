﻿using System;
using System.Collections.Generic;

namespace SAN.Models
{
    /// <summary>
    /// Lookup table containing the types of contacts stored in Contact.
    /// </summary>
    public partial class ContactType
    {
        /// <summary>
        /// Primary key for ContactType records.
        /// </summary>
        public int ContactTypeId { get; set; }
        /// <summary>
        /// Contact type description.
        /// </summary>
        public string Name { get; set; } = null!;
        /// <summary>
        /// Date and time the record was last updated.
        /// </summary>
        public DateTime ModifiedDate { get; set; }
    }
}
